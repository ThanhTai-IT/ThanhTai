/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DoAn_CSS311_ThanhTai;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Optional;
import java.util.Scanner;
import javax.naming.spi.NamingManager;

/**
 *
 * @author admin
 */
public class QuanLiThuVien {

    private ArrayList<ThuocTinh> a = new ArrayList<>();

    public ArrayList<ThuocTinh> getA() {
        return a;
    }

    public void setA(ArrayList<ThuocTinh> a) {
        this.a = a;
    }

    public void docFile(String tenFile) {
        try {
            File f = new File(tenFile);
            if (f.exists()) {
                System.out.println("Ok co file");
                Scanner read = new Scanner(f);
                while (read.hasNext()) {
                    String s[] = read.nextLine().split(", ");
                    String ma = s[1];
                    String ten = s[2];
                    boolean loai = Boolean.parseBoolean(s[3]);
                    String tacgia = s[4];
                    String nhaXuatBan = s[5];
                    int namXuatBan = Integer.parseInt(s[6]);
                    ngay ngaynhap = new ngay(s[7]);
                    String ngonNgu = s[8];
                    int soTrang = Integer.parseInt(s[9]);
                    int soLuong = Integer.parseInt(s[10]);
                    int soLuongTrongKho = Integer.parseInt(s[11]);
                    double giaTien = Double.parseDouble(s[12]);
                    int soThuTu = Integer.parseInt(s[0]);
                    if (loai == true) {
                        String khoiLop = s[13];
                        a.add(new SachGiaoKhoa(khoiLop, soThuTu, ma, namXuatBan, soTrang, soLuong, ten, tacgia, nhaXuatBan, ngonNgu, loai, ngaynhap, giaTien, soLuongTrongKho));
                    } else {
                        a.add(new Truyen(s[13], soThuTu, ma, namXuatBan, soTrang, soLuong, ten, tacgia, nhaXuatBan, ngonNgu, loai, ngaynhap, giaTien, soLuongTrongKho));
                    }
                }
            } else {
                System.out.println("Khong co file");
            }
        } catch (Exception e) {
        }
    }

    public void xuat(ArrayList b, String noidung) {
        System.out.println(noidung);
        for (Object x : b) {
            System.out.println(x);
        }
    }

    public boolean them(ThuocTinh y) {
        for (ThuocTinh x : a) {
            if (x.getMaSach().equalsIgnoreCase(y.getMaSach()) || x.getSoThuTu() == y.getSoThuTu()) {
                return false;
            }

        }
        a.add(y);
        return true;
    }

    public int getSoLuong(String y) {
        int soLuong = 0;
        for (ThuocTinh x : a) {
            if (x.getClass().getSimpleName().equalsIgnoreCase(y)) {
                soLuong += x.getSoLuong();
            }
        }
        return soLuong;
    }

    public int getSoLuongChung(String y) {
        int soLuong = 0;
        for (ThuocTinh x : a) {
            if (y.equalsIgnoreCase("chung")) {
                soLuong += x.getSoLuong();
            }
        }
        return soLuong;
    }

    public double tongTienNhap() {
        double tongTien = 0;
        for (ThuocTinh x : a) {
            tongTien += x.getTienDaNhap();
        }
        return tongTien;
    }

    public double tongTienNhapSachGK() {
        double tongTien = 0;
        for (ThuocTinh x : a) {
            if (x instanceof SachGiaoKhoa) {
                tongTien += x.getTienDaNhap();
            }
        }
        return tongTien;
    }

    public double tongTienNhapTruyen() {
        double tongTien = 0;
        for (ThuocTinh x : a) {
            if (x instanceof Truyen) {
                tongTien += x.getTienDaNhap();
            }
        }
        return tongTien;
    }

    public void timKiem(String y) {
        for (ThuocTinh x : a) {
            if (x.getMaSach().equalsIgnoreCase(y)) {
                System.out.println(x);
            }
        }
    }

    public void tangTheoSoLuong() {
        Collections.sort(a, Comparator.comparingInt(ThuocTinh::getSoLuongTrongKho));
    }

    public void giamTheoSoLuong() {
        Collections.sort(a, Comparator.comparingInt(ThuocTinh::getSoLuongTrongKho).reversed());

    }

    public void xuatFile(String tenfile) {
        try {
            FileWriter fw = new FileWriter(tenfile);
            BufferedWriter bw = new BufferedWriter(fw);

            for (ThuocTinh x : a) {
                bw.write(x.toString());
                bw.newLine();
            }
            bw.close();
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

    public void output() {
        xuat(a, "Danh sach: ");
        //them(y);
//        xoa(ma);
        System.out.println("Tong tien da nhap: " + tongTienNhap());
        timKiem("978604013944");
        xuatFile("file.txt");
    }

    public static void main(String[] args) {
        QuanLiThuVien a = new QuanLiThuVien();
        a.docFile("vvttne.txt");
        a.output();

    }

}
