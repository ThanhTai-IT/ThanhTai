/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DoAn_CSS311_ThanhTai;

/**
 *
 * @author admin
 */
public class SachGiaoKhoa extends ThuocTinh {

    private String khoiLopSuDung;

    public SachGiaoKhoa(String khoiLopSuDung, int soThuTu, String maSach, int namXuatBan, int soTrang, int soLuong, String tenSach, String tacGia, String nhaXuatBan, String ngonNgu, boolean loaiSach, ngay ngayNhap, double giaTien, int soLuongTrongKho) {
        super(soThuTu, maSach, namXuatBan, soTrang, soLuong, tenSach, tacGia, nhaXuatBan, ngonNgu, loaiSach, ngayNhap, giaTien, soLuongTrongKho);
        this.khoiLopSuDung = khoiLopSuDung;
    }

    public String getKhoiLopSuDung() {
        return khoiLopSuDung;
    }

    public void setKhoiLopSuDung(String khoiLopSuDung) {
        this.khoiLopSuDung = khoiLopSuDung;
    }

    

    @Override
    public String toString() {
        return "Sách Giáo Khoa" + super.toString() + ", khối lớp sử dụng: " + khoiLopSuDung + ", tình trạng: " +gettinhTrang() + ", tổng tiền đã nhập: " +getTienDaNhap();
    }

    @Override
    public String gettinhTrang() {
        if (getSoLuongTrongKho()== 0) {
            return "Đã hết";
        }
        return "Sẵn sàng cho thuê";
    }

    @Override
    public double getTienDaNhap() {
        return getSoLuong() * getGiaTien();
    }

}
