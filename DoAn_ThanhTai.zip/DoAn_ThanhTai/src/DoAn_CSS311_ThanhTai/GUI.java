package DoAn_CSS311_ThanhTai;

import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class GUI extends javax.swing.JFrame {

    private DefaultTableModel dfm = new DefaultTableModel();
    QuanLiThuVien a = new QuanLiThuVien();

    public GUI() {
        dfm.setColumnIdentifiers(new Object[]{"STT", "MÃ SÁCH", "TÊN SÁCH", "THỂ LOẠI", "KHỐI LỚP", "LOẠI TRUYỆN", "TÁC GIẢ", "NHÀ XUẤT BẢN",
            "NĂM XUẤT BẢN", "NGÀY NHẬP", "NGÔN NGỮ", "SỐ LƯỢNG HIỆN CÓ", "TÌNH TRẠNG", "SỐ TRANG", "SỐ LƯỢNG NHẬP", "GIÁ TIỀN(1 Quyển)", "TIỀN ĐÃ NHẬP"});
        initComponents();
        setIconimage();
        tablehienthi.setModel(dfm);
        // Kich Thuoc Cot Table
        setColumnWidth(0, 5); // SỐ THỨ TỰ
        setColumnWidth(1, 50); // MÃ SÁCH
        setColumnWidth(2, 80); // TÊN SÁCH
        setColumnWidth(3, 70); // THỂ LOẠI
        setColumnWidth(4, 50); // KHỐI LỚP
        setColumnWidth(5, 60); // LOẠI TRUYỆN
        setColumnWidth(6, 70); // TÁC GIẢ
        setColumnWidth(7, 80); // NHÀ XUẤT BẢN
        setColumnWidth(8, 70); // NĂM XUẤT BẢN
        setColumnWidth(9, 50); // NGÀY NHẬP
        setColumnWidth(10, 50); //NGÔN NGỮ
        setColumnWidth(11, 100); //SỐ LƯỢNG HIỆN CÓ
        setColumnWidth(12, 80); // TÌNH TRẠNG
        setColumnWidth(13, 50); //SỐ TRANG
        setColumnWidth(14, 80); // SỐ LƯỢNG NHẬP
        setColumnWidth(15, 100); // GIÁ TIỀN
        setColumnWidth(16, 100); // TIỀN ĐÃ NHẬP

    }

    public void loadData(ArrayList<ThuocTinh> b) {
        while (dfm.getRowCount() > 0) {
            dfm.removeRow(0);
        }
        for (ThuocTinh x : b) {
            if (x instanceof SachGiaoKhoa) {
                dfm.addRow(new Object[]{x.getSoThuTu(), x.getMaSach(), x.getTenSach(), "Sách Giáo Khoa", ((SachGiaoKhoa) x).getKhoiLopSuDung(), "", x.getTacGia(), x.getNhaXuatBan(), x.getNamXuatBan(),
                    x.getNgayNhap(), x.getNgonNgu(), x.getSoLuongTrongKho(), x.gettinhTrang(), x.getSoTrang(), x.getSoLuong(), x.getGiaTien(), x.getTienDaNhap()});
            }
            if (x instanceof Truyen) {
                dfm.addRow(new Object[]{x.getSoThuTu(), x.getMaSach(), x.getTenSach(), "Truyện", "", ((Truyen) x).getTheLoaiTruyen(), x.getTacGia(), x.getNhaXuatBan(), x.getNamXuatBan(),
                    x.getNgayNhap(), x.getNgonNgu(), x.getSoLuongTrongKho(), x.gettinhTrang(), x.getSoTrang(), x.getSoLuong(), x.getGiaTien(), x.getTienDaNhap()});
            }
        }
    }

    private void setColumnWidth(int columnIndex, int width) {
        TableColumn column = tablehienthi.getColumnModel().getColumn(columnIndex);
        column.setPreferredWidth(width);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        panelchung = new javax.swing.JTabbedPane();
        panelsach = new javax.swing.JPanel();
        panelthongtinsach = new javax.swing.JPanel();
        lbtensach = new javax.swing.JLabel();
        lbtacgia = new javax.swing.JLabel();
        lbtheloai = new javax.swing.JLabel();
        txttensach = new javax.swing.JTextField();
        lbsoluong = new javax.swing.JLabel();
        txttacgia = new javax.swing.JTextField();
        txtsoluong = new javax.swing.JTextField();
        lbnhaxuatban = new javax.swing.JLabel();
        lbngonngu = new javax.swing.JLabel();
        lbnamxuatban = new javax.swing.JLabel();
        txtnhaxuatban = new javax.swing.JTextField();
        txtnamxuatban = new javax.swing.JTextField();
        lbsotrang = new javax.swing.JLabel();
        txtsotrang = new javax.swing.JTextField();
        lbngaynhap = new javax.swing.JLabel();
        lbgiatien = new javax.swing.JLabel();
        txtngaynhap = new javax.swing.JTextField();
        txtgiatien = new javax.swing.JTextField();
        lbvnd = new javax.swing.JLabel();
        rbsachgiaokhoa = new javax.swing.JRadioButton();
        rbtruyen = new javax.swing.JRadioButton();
        txtngonngu = new javax.swing.JTextField();
        btlammoi = new javax.swing.JButton();
        lbsoluonghienco = new javax.swing.JLabel();
        txtsoluonghienco = new javax.swing.JTextField();
        lbkhoilop = new javax.swing.JLabel();
        txtkhoilop = new javax.swing.JTextField();
        lbsothutu = new javax.swing.JLabel();
        txtsothutu = new javax.swing.JTextField();
        lbmasach = new javax.swing.JLabel();
        txtmasach = new javax.swing.JTextField();
        lbthongtinsach = new javax.swing.JLabel();
        btthem = new javax.swing.JButton();
        btxoa = new javax.swing.JButton();
        btsua = new javax.swing.JButton();
        btdocfile = new javax.swing.JButton();
        fbxuatfile = new javax.swing.JButton();
        btthoat = new javax.swing.JButton();
        bttimkiem = new javax.swing.JButton();
        paneltable = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablehienthi = new javax.swing.JTable();
        bttongtiennhap = new javax.swing.JButton();
        bttongslhienco = new javax.swing.JButton();
        btsapxeptang = new javax.swing.JButton();
        btsapxepgiam = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Quản Lí Thư Viện");
        setResizable(false);

        panelsach.setBackground(new java.awt.Color(204, 255, 255));
        panelsach.setForeground(new java.awt.Color(102, 255, 0));

        panelthongtinsach.setBackground(new java.awt.Color(153, 255, 255));
        panelthongtinsach.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panelthongtinsach.setForeground(new java.awt.Color(255, 153, 153));

        lbtensach.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbtensach.setText("Tên sách: ");

        lbtacgia.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbtacgia.setText("Tác giả:");

        lbtheloai.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbtheloai.setText("Thể loại:");

        lbsoluong.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbsoluong.setText("Số lượng nhập:");

        lbnhaxuatban.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbnhaxuatban.setText("Nhà xuất bản:");

        lbngonngu.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbngonngu.setText("Ngôn ngữ:");

        lbnamxuatban.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbnamxuatban.setText("Năm xuất bản:");

        txtnamxuatban.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnamxuatbanActionPerformed(evt);
            }
        });

        lbsotrang.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbsotrang.setText("Số trang:");

        lbngaynhap.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbngaynhap.setText("Ngày nhập:");

        lbgiatien.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbgiatien.setText("Giá tiền:");

        lbvnd.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbvnd.setText("VNĐ");

        buttonGroup1.add(rbsachgiaokhoa);
        rbsachgiaokhoa.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rbsachgiaokhoa.setSelected(true);
        rbsachgiaokhoa.setText("Sách Giáo Khoa");
        rbsachgiaokhoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbsachgiaokhoaActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtruyen);
        rbtruyen.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rbtruyen.setText("Truyện");
        rbtruyen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtruyenActionPerformed(evt);
            }
        });

        txtngonngu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtngonnguActionPerformed(evt);
            }
        });

        btlammoi.setBackground(new java.awt.Color(153, 153, 255));
        btlammoi.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btlammoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/undo.png"))); // NOI18N
        btlammoi.setText("Làm mới");
        btlammoi.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btlammoi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btlammoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlammoiActionPerformed(evt);
            }
        });

        lbsoluonghienco.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbsoluonghienco.setText("Số lượng hiện có:");

        lbkhoilop.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbkhoilop.setText("Khối lớp:");

        txtkhoilop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtkhoilopActionPerformed(evt);
            }
        });

        lbsothutu.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbsothutu.setText("STT:");

        lbmasach.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        lbmasach.setText("Mã sách:");

        txtmasach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmasachActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelthongtinsachLayout = new javax.swing.GroupLayout(panelthongtinsach);
        panelthongtinsach.setLayout(panelthongtinsachLayout);
        panelthongtinsachLayout.setHorizontalGroup(
            panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelthongtinsachLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelthongtinsachLayout.createSequentialGroup()
                        .addComponent(lbsothutu)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtsothutu))
                    .addGroup(panelthongtinsachLayout.createSequentialGroup()
                        .addComponent(lbmasach, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtmasach, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(6, 6, Short.MAX_VALUE)
                .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(panelthongtinsachLayout.createSequentialGroup()
                            .addComponent(lbtensach, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txttensach))
                        .addGroup(panelthongtinsachLayout.createSequentialGroup()
                            .addComponent(lbtacgia)
                            .addGap(18, 18, 18)
                            .addComponent(txttacgia, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelthongtinsachLayout.createSequentialGroup()
                        .addComponent(lbtheloai)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rbsachgiaokhoa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbtruyen)))
                .addGap(160, 160, 160)
                .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbnamxuatban, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbnhaxuatban)
                    .addComponent(lbngonngu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelthongtinsachLayout.createSequentialGroup()
                        .addComponent(txtnamxuatban, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lbsotrang, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtsotrang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtnhaxuatban)
                    .addComponent(txtngonngu, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(160, 160, 160)
                .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbngaynhap)
                    .addComponent(lbgiatien)
                    .addComponent(lbsoluong))
                .addGap(10, 10, 10)
                .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtngaynhap, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelthongtinsachLayout.createSequentialGroup()
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelthongtinsachLayout.createSequentialGroup()
                                .addComponent(txtsoluong, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lbsoluonghienco)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtsoluonghienco, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                            .addComponent(txtgiatien))
                        .addGap(1, 1, 1)))
                .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelthongtinsachLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelthongtinsachLayout.createSequentialGroup()
                                .addComponent(lbvnd)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(panelthongtinsachLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(lbkhoilop, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtkhoilop, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(49, 49, 49))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelthongtinsachLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btlammoi)
                        .addContainerGap())))
        );
        panelthongtinsachLayout.setVerticalGroup(
            panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelthongtinsachLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelthongtinsachLayout.createSequentialGroup()
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbnhaxuatban)
                            .addComponent(txtnhaxuatban, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbngonngu)
                            .addComponent(txtngonngu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbnamxuatban)
                            .addComponent(txtnamxuatban, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbsotrang)
                            .addComponent(txtsotrang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelthongtinsachLayout.createSequentialGroup()
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbtensach)
                            .addComponent(txttensach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbtacgia)
                            .addComponent(txttacgia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbtheloai)
                            .addComponent(rbsachgiaokhoa)
                            .addComponent(rbtruyen)))
                    .addGroup(panelthongtinsachLayout.createSequentialGroup()
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbngaynhap)
                            .addComponent(txtngaynhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbkhoilop)
                            .addComponent(txtkhoilop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbsothutu)
                            .addComponent(txtsothutu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lbgiatien)
                                .addComponent(txtgiatien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lbvnd))
                            .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lbmasach)
                                .addComponent(txtmasach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelthongtinsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lbsoluong)
                                .addComponent(txtsoluong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lbsoluonghienco)
                                .addComponent(txtsoluonghienco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelthongtinsachLayout.createSequentialGroup()
                                .addComponent(btlammoi, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(3, 3, 3)))))
                .addContainerGap(3, Short.MAX_VALUE))
        );

        lbthongtinsach.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbthongtinsach.setText("Thông tin sách");

        btthem.setBackground(new java.awt.Color(204, 204, 255));
        btthem.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btthem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/new.png"))); // NOI18N
        btthem.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btthem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btthem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btthemMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btthemMouseExited(evt);
            }
        });
        btthem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btthemActionPerformed(evt);
            }
        });

        btxoa.setBackground(new java.awt.Color(204, 204, 0));
        btxoa.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btxoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/delete.png"))); // NOI18N
        btxoa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btxoa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btxoa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btxoaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btxoaMouseExited(evt);
            }
        });
        btxoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btxoaActionPerformed(evt);
            }
        });

        btsua.setBackground(new java.awt.Color(255, 204, 204));
        btsua.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btsua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/edit.png"))); // NOI18N
        btsua.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btsua.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btsua.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btsuaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btsuaMouseExited(evt);
            }
        });
        btsua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btsuaActionPerformed(evt);
            }
        });

        btdocfile.setBackground(new java.awt.Color(255, 153, 153));
        btdocfile.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btdocfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/open.png"))); // NOI18N
        btdocfile.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btdocfile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btdocfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btdocfileMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btdocfileMouseExited(evt);
            }
        });
        btdocfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btdocfileActionPerformed(evt);
            }
        });

        fbxuatfile.setBackground(new java.awt.Color(102, 255, 0));
        fbxuatfile.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        fbxuatfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/xuatfile.png"))); // NOI18N
        fbxuatfile.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        fbxuatfile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        fbxuatfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                fbxuatfileMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                fbxuatfileMouseExited(evt);
            }
        });
        fbxuatfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fbxuatfileActionPerformed(evt);
            }
        });

        btthoat.setBackground(new java.awt.Color(255, 204, 0));
        btthoat.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btthoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/thoat.png"))); // NOI18N
        btthoat.setText("Thoát");
        btthoat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btthoat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btthoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btthoatActionPerformed(evt);
            }
        });

        bttimkiem.setBackground(new java.awt.Color(153, 255, 102));
        bttimkiem.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        bttimkiem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search.png"))); // NOI18N
        bttimkiem.setText("Tìm kiếm");
        bttimkiem.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        bttimkiem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bttimkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttimkiemActionPerformed(evt);
            }
        });

        paneltable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tablehienthi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tablehienthi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablehienthiMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablehienthi);

        javax.swing.GroupLayout paneltableLayout = new javax.swing.GroupLayout(paneltable);
        paneltable.setLayout(paneltableLayout);
        paneltableLayout.setHorizontalGroup(
            paneltableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(paneltableLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        paneltableLayout.setVerticalGroup(
            paneltableLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, paneltableLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE)
                .addContainerGap())
        );

        bttongtiennhap.setBackground(new java.awt.Color(255, 0, 0));
        bttongtiennhap.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bttongtiennhap.setText("Tổng Tiền Nhập");
        bttongtiennhap.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bttongtiennhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttongtiennhapActionPerformed(evt);
            }
        });

        bttongslhienco.setBackground(new java.awt.Color(255, 0, 0));
        bttongslhienco.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bttongslhienco.setText("Tổng SL Nhập");
        bttongslhienco.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bttongslhienco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttongslhiencoActionPerformed(evt);
            }
        });

        btsapxeptang.setBackground(new java.awt.Color(255, 0, 0));
        btsapxeptang.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btsapxeptang.setForeground(new java.awt.Color(51, 51, 51));
        btsapxeptang.setText("Sắp xếp tăng");
        btsapxeptang.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btsapxeptang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btsapxeptangActionPerformed(evt);
            }
        });

        btsapxepgiam.setBackground(new java.awt.Color(255, 0, 0));
        btsapxepgiam.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btsapxepgiam.setForeground(new java.awt.Color(51, 51, 51));
        btsapxepgiam.setText("Sắp xếp giảm");
        btsapxepgiam.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btsapxepgiam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btsapxepgiamActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelsachLayout = new javax.swing.GroupLayout(panelsach);
        panelsach.setLayout(panelsachLayout);
        panelsachLayout.setHorizontalGroup(
            panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelsachLayout.createSequentialGroup()
                .addGroup(panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelsachLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(paneltable, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(panelthongtinsach, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelsachLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbthongtinsach, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(panelsachLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelsachLayout.createSequentialGroup()
                                .addComponent(btdocfile)
                                .addGap(18, 18, 18)
                                .addComponent(fbxuatfile))
                            .addGroup(panelsachLayout.createSequentialGroup()
                                .addComponent(btthem)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btxoa)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btsua)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bttongslhienco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btsapxeptang, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(panelsachLayout.createSequentialGroup()
                                .addComponent(btsapxepgiam, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(23, 23, 23)
                                .addComponent(bttimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelsachLayout.createSequentialGroup()
                                .addComponent(bttongtiennhap)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btthoat)))))
                .addContainerGap())
        );
        panelsachLayout.setVerticalGroup(
            panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelsachLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(lbthongtinsach)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelthongtinsach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btthem, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btxoa, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btsua, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btthoat, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttongslhienco, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttongtiennhap, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE))
                .addGap(23, 23, 23)
                .addGroup(panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btsapxeptang, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelsachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btdocfile, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(bttimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btsapxepgiam, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(fbxuatfile, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(paneltable, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelchung.addTab("Sách", panelsach);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelchung)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelchung)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bttongslhiencoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttongslhiencoActionPerformed
        // TODO add your handling code here:
        String loaiSach = JOptionPane.showInputDialog(rootPane, "Nhập loại sách cần kiểm tra số lượng (Truyen hoặc SachGiaoKhoa hoặc Chung)");
        if (loaiSach.equalsIgnoreCase("Truyen")) {
            JOptionPane.showMessageDialog(null, "Tổng số lượng truyện đã nhập: "
                    + a.getSoLuong(loaiSach), "TỔNG SỐ LƯỢNG", JOptionPane.CLOSED_OPTION);
        } else if (loaiSach.equalsIgnoreCase("SachGiaoKhoa")) {
            JOptionPane.showMessageDialog(null, "Tổng số lượng truyện đã nhập: "
                    + a.getSoLuong(loaiSach), "TỔNG SỐ LƯỢNG", JOptionPane.CLOSED_OPTION);
        } else if (loaiSach.equalsIgnoreCase("chung")) {
            JOptionPane.showMessageDialog(null, "Tổng số lượng truyện và sách giáo khoa đã nhập: "
                    + a.getSoLuongChung(loaiSach), "TỔNG SỐ LƯỢNG CHUNG", JOptionPane.CLOSED_OPTION);
        } else {
            JOptionPane.showMessageDialog(null, "Không có loại sách mà bạn cần, vui lòng nhập lại ! (Truyen hoặc SachGiaoKhoa hoặc Chung) ",
                    "LỖI", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_bttongslhiencoActionPerformed

    private void bttongtiennhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttongtiennhapActionPerformed
        // TODO add your handling code here:
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null,
                "Tổng tiền sách giáo khoa đã nhập: " + a.tongTienNhapSachGK() + "\n"
                + "Tổng tiền truyện đã nhập: " + a.tongTienNhapTruyen() + "\n"
                + "Tổng tiền đã nhập: " + a.tongTienNhap(), "TỔNG TIỀN", JOptionPane.CLOSED_OPTION);
    }//GEN-LAST:event_bttongtiennhapActionPerformed

    private void tablehienthiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablehienthiMouseClicked
        // TODO add your handling code here:
        ArrayList<ThuocTinh> b = a.getA();
        int mucluc = tablehienthi.getSelectedRow();
        txtmasach.setText(b.get(mucluc).getMaSach());
        txtgiatien.setText("" + b.get(mucluc).getGiaTien());
        txtnamxuatban.setText("" + b.get(mucluc).getNamXuatBan());
        txtngaynhap.setText("" + b.get(mucluc).getNgayNhap());
        txtngonngu.setText(b.get(mucluc).getNgonNgu());
        txtnhaxuatban.setText(b.get(mucluc).getNhaXuatBan());
        txtsoluong.setText("" + b.get(mucluc).getSoLuong());
        txtsoluonghienco.setText("" + b.get(mucluc).getSoLuongTrongKho());
        txtsothutu.setText("" + b.get(mucluc).getSoThuTu());
        txtsotrang.setText("" + b.get(mucluc).getSoTrang());
        txttacgia.setText(b.get(mucluc).getTacGia());
        txttensach.setText(b.get(mucluc).getTenSach());
        if (b.get(mucluc) instanceof SachGiaoKhoa) {
            rbsachgiaokhoa.setSelected(true);
            lbkhoilop.setText("Khối lớp:");
            txtkhoilop.setText(((SachGiaoKhoa) b.get(mucluc)).getKhoiLopSuDung());
        } else {
            rbtruyen.setSelected(true);
            lbkhoilop.setText("Loại Truyện: ");
            txtkhoilop.setText(((Truyen) b.get(mucluc)).getTheLoaiTruyen());
        }


    }//GEN-LAST:event_tablehienthiMouseClicked

    private void btthoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btthoatActionPerformed
        // TODO add your handling code here:
        int luachon = JOptionPane.showConfirmDialog(rootPane, "Bạn muốn thoát khỏi chương trình ?");
        if (luachon == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_btthoatActionPerformed

    private void btdocfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btdocfileActionPerformed
        // TODO add your handling code here:
        JFileChooser docfile = new JFileChooser();
        docfile.showOpenDialog(null);
        String tenfile = docfile.getSelectedFile().getPath();
        a.docFile(tenfile);
        loadData(a.getA());
    }//GEN-LAST:event_btdocfileActionPerformed

    private void btsuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btsuaActionPerformed
        // TODO add your handling code here:
        try {
            int mucluc = tablehienthi.getSelectedRow();
            ThuocTinh y;
            int soThuTu = Integer.parseInt(txtsothutu.getText());
            String ma = txtmasach.getText();
            String tensach = txttensach.getText();
            boolean theloai = rbsachgiaokhoa.isSelected();
            String tacgia = txttacgia.getText();
            String nhaxuatban = txtnhaxuatban.getText();
            int namXuatBan = Integer.parseInt(txtnamxuatban.getText());
            ngay ngaynhap = new ngay(txtngaynhap.getText());
            String ngonngu = txtngonngu.getText();
            int soLuongHienco = Integer.parseInt(txtsoluonghienco.getText());
            int soTrang = Integer.parseInt(txtsotrang.getText());
            int soLuongNhap = Integer.parseInt(txtsoluong.getText());
            double giaTien = Double.parseDouble(txtgiatien.getText());
            if (rbsachgiaokhoa.isSelected()) {
                String khoiLop = txtkhoilop.getText();
                y = new SachGiaoKhoa(khoiLop, soThuTu, ma, namXuatBan, soTrang, soLuongNhap, tensach, tacgia, nhaxuatban, ngonngu, theloai, ngaynhap, giaTien, soLuongHienco);
            } else {
                String khoilop = txtkhoilop.getText();
                y = new Truyen(khoilop, soThuTu, ma, namXuatBan, soTrang, soLuongNhap, tensach, tacgia, nhaxuatban, ngonngu, theloai, ngaynhap, giaTien, soLuongHienco);
            }
            int chon = JOptionPane.showConfirmDialog(rootPane, "Bạn có muốn lưu không ?");
            if (chon == 0) {
                ArrayList<ThuocTinh> b = a.getA();
                b.set(mucluc, y);
                a.setA(b);
                loadData(a.getA());
            } else {
                JOptionPane.showMessageDialog(rootPane, "Bạn chọn không lưu !");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "Bạn chưa chọn dòng để sửa");
        }
    }//GEN-LAST:event_btsuaActionPerformed

    private void btxoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btxoaActionPerformed
        // TODO add your handling code here:
        Iterator<ThuocTinh> iterator = a.getA().iterator();
        String maNhap = JOptionPane.showInputDialog(rootPane, "Nhập mã sách cần xóa:");
        int check = 0;
        while (iterator.hasNext()) {
            ThuocTinh x = iterator.next();
            if (x.getMaSach().equalsIgnoreCase(maNhap)) {
                int luachon = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn muốn xóa?");
                if (luachon == 0) {
                    iterator.remove();  //
                    loadData(a.getA());
                    check = check + 1;
                    break;
                }
            }
        }
        if (check == 0) {
            JOptionPane.showMessageDialog(rootPane, "Không có mã sách này vì vậy không thể xóa được ! ", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btxoaActionPerformed

    private void btthemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btthemActionPerformed
        // TODO add your handling code here:
        try {
            ThuocTinh y;
            int soThuTu = Integer.parseInt(txtsothutu.getText());
            String ma = txtmasach.getText();
            String tensach = txttensach.getText();
            boolean theloai = rbsachgiaokhoa.isSelected();
            String tacgia = txttacgia.getText();
            String nhaxuatban = txtnhaxuatban.getText();
            int namXuatBan = Integer.parseInt(txtnamxuatban.getText());
            ngay ngaynhap = new ngay(txtngaynhap.getText());
            String ngonngu = txtngonngu.getText();
            int soLuongHienco = Integer.parseInt(txtsoluonghienco.getText());
            int soTrang = Integer.parseInt(txtsotrang.getText());
            int soLuongNhap = Integer.parseInt(txtsoluong.getText());
            double giaTien = Double.parseDouble(txtgiatien.getText());
            if (rbsachgiaokhoa.isSelected()) {
                String khoiLop = txtkhoilop.getText();
                y = new SachGiaoKhoa(khoiLop, soThuTu, ma, namXuatBan, soTrang, soLuongNhap, tensach, tacgia, nhaxuatban, ngonngu, theloai, ngaynhap, giaTien, soLuongHienco);
            } else {
                String khoilop = txtkhoilop.getText();
                y = new Truyen(khoilop, soThuTu, ma, namXuatBan, soTrang, soLuongNhap, tensach, tacgia, nhaxuatban, ngonngu, theloai, ngaynhap, giaTien, soLuongHienco);
            }
            if (a.them(y)) {
                loadData(a.getA());
            } else {
                JOptionPane.showMessageDialog(this, "Mã sách hoặc số thứ tự đã tồn tại !", "LỖI", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Bạn chưa nhập thông tin để thêm !", "LỖI", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btthemActionPerformed

    private void txtmasachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmasachActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtmasachActionPerformed

    private void txtkhoilopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtkhoilopActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtkhoilopActionPerformed

    private void btlammoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlammoiActionPerformed
        // TODO add your handling code here:
        txtsothutu.setText("");
        txtmasach.setText("");
        txttensach.setText("");
        rbsachgiaokhoa.setSelected(true);
        txttacgia.setText("");
        txtnhaxuatban.setText("");
        txtnamxuatban.setText("");
        txtngaynhap.setText("");
        txtngonngu.setText("");
        txtsoluonghienco.setText("");
        txtsotrang.setText("");
        txtsoluong.setText("");
        txtgiatien.setText("");
        txtkhoilop.setText("");
    }//GEN-LAST:event_btlammoiActionPerformed

    private void txtngonnguActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtngonnguActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtngonnguActionPerformed

    private void rbtruyenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtruyenActionPerformed
        // TODO add your handling code here:
        rbsachgiaokhoa.isSelected();
        lbkhoilop.setText("Loại Truyện");
        lbkhoilop.setVisible(true);
        txtkhoilop.setVisible(true);
    }//GEN-LAST:event_rbtruyenActionPerformed

    private void rbsachgiaokhoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbsachgiaokhoaActionPerformed
        // TODO add your handling code here:
        lbkhoilop.setText("Khối Lớp");
        lbkhoilop.setVisible(true);
        txtkhoilop.setVisible(true);
    }//GEN-LAST:event_rbsachgiaokhoaActionPerformed

    private void txtnamxuatbanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnamxuatbanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnamxuatbanActionPerformed

    private void btsapxeptangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btsapxeptangActionPerformed
        // TODO add your handling code here
        a.tangTheoSoLuong();
        loadData(a.getA());
    }//GEN-LAST:event_btsapxeptangActionPerformed

    private void btsapxepgiamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btsapxepgiamActionPerformed
        // TODO add your handling code here:
        a.giamTheoSoLuong();
        loadData(a.getA());
    }//GEN-LAST:event_btsapxepgiamActionPerformed

    private void btxoaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btxoaMouseEntered
        // TODO add your handling code here:
        btxoa.setText("Xóa");
    }//GEN-LAST:event_btxoaMouseEntered

    private void btxoaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btxoaMouseExited
        // TODO add your handling code here:
        btxoa.setText("");
    }//GEN-LAST:event_btxoaMouseExited

    private void btthemMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btthemMouseEntered
        // TODO add your handling code here:
        btthem.setText("Thêm");
    }//GEN-LAST:event_btthemMouseEntered

    private void btthemMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btthemMouseExited
        // TODO add your handling code here:
        btthem.setText("");
    }//GEN-LAST:event_btthemMouseExited

    private void fbxuatfileMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fbxuatfileMouseEntered
        // TODO add your handling code here:
        fbxuatfile.setText("Xuất File");
    }//GEN-LAST:event_fbxuatfileMouseEntered

    private void fbxuatfileMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fbxuatfileMouseExited
        // TODO add your handling code here:
        fbxuatfile.setText("");
    }//GEN-LAST:event_fbxuatfileMouseExited

    private void btdocfileMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btdocfileMouseEntered
        // TODO add your handling code here:
        btdocfile.setText("Đọc File");
    }//GEN-LAST:event_btdocfileMouseEntered

    private void btdocfileMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btdocfileMouseExited
        // TODO add your handling code here:
        btdocfile.setText("");
    }//GEN-LAST:event_btdocfileMouseExited

    private void btsuaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btsuaMouseEntered
        // TODO add your handling code here:
        btsua.setText("Sửa");
    }//GEN-LAST:event_btsuaMouseEntered

    private void btsuaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btsuaMouseExited
        // TODO add your handling code here:
        btsua.setText("");
    }//GEN-LAST:event_btsuaMouseExited

    private void bttimkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttimkiemActionPerformed
        // TODO add your handling code here:
        Iterator<ThuocTinh> timkiem = a.getA().iterator();
        String maSach = JOptionPane.showInputDialog("Nhập mã sách:");
        int check = 0;
        while (timkiem.hasNext()) {
            ThuocTinh x = timkiem.next();
            if (x.getMaSach().equalsIgnoreCase(maSach)) {
                JOptionPane.showMessageDialog(null, x);
                check = check + 1;
                break;
            }
        }
        if (check == 0) {
            JOptionPane.showMessageDialog(rootPane, "Không có mã sách này trong bảng ", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_bttimkiemActionPerformed

    private void fbxuatfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fbxuatfileActionPerformed
        JFileChooser xuatfile = new JFileChooser();
        xuatfile.showSaveDialog(this);
        String tenfile = xuatfile.getSelectedFile().getPath();

        if (!tenfile.endsWith(".txt")) {
            tenfile += ".txt";
        }
        a.xuatFile(tenfile);
        JOptionPane.showMessageDialog(null, "Dữ liệu đã được xuất thành công vào tệp tin.");
    }//GEN-LAST:event_fbxuatfileActionPerformed

    public void setIconimage() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/icon/quanli1.png")));
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btdocfile;
    private javax.swing.JButton btlammoi;
    private javax.swing.JButton btsapxepgiam;
    private javax.swing.JButton btsapxeptang;
    private javax.swing.JButton btsua;
    private javax.swing.JButton btthem;
    private javax.swing.JButton btthoat;
    private javax.swing.JButton bttimkiem;
    private javax.swing.JButton bttongslhienco;
    private javax.swing.JButton bttongtiennhap;
    private javax.swing.JButton btxoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton fbxuatfile;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbgiatien;
    private javax.swing.JLabel lbkhoilop;
    private javax.swing.JLabel lbmasach;
    private javax.swing.JLabel lbnamxuatban;
    private javax.swing.JLabel lbngaynhap;
    private javax.swing.JLabel lbngonngu;
    private javax.swing.JLabel lbnhaxuatban;
    private javax.swing.JLabel lbsoluong;
    private javax.swing.JLabel lbsoluonghienco;
    private javax.swing.JLabel lbsothutu;
    private javax.swing.JLabel lbsotrang;
    private javax.swing.JLabel lbtacgia;
    private javax.swing.JLabel lbtensach;
    private javax.swing.JLabel lbtheloai;
    private javax.swing.JLabel lbthongtinsach;
    private javax.swing.JLabel lbvnd;
    private javax.swing.JTabbedPane panelchung;
    private javax.swing.JPanel panelsach;
    private javax.swing.JPanel paneltable;
    private javax.swing.JPanel panelthongtinsach;
    private javax.swing.JRadioButton rbsachgiaokhoa;
    private javax.swing.JRadioButton rbtruyen;
    private javax.swing.JTable tablehienthi;
    private javax.swing.JTextField txtgiatien;
    private javax.swing.JTextField txtkhoilop;
    private javax.swing.JTextField txtmasach;
    private javax.swing.JTextField txtnamxuatban;
    private javax.swing.JTextField txtngaynhap;
    private javax.swing.JTextField txtngonngu;
    private javax.swing.JTextField txtnhaxuatban;
    private javax.swing.JTextField txtsoluong;
    private javax.swing.JTextField txtsoluonghienco;
    private javax.swing.JTextField txtsothutu;
    private javax.swing.JTextField txtsotrang;
    private javax.swing.JTextField txttacgia;
    private javax.swing.JTextField txttensach;
    // End of variables declaration//GEN-END:variables
}
