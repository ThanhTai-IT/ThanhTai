/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DoAn_CSS311_ThanhTai;

/**
 *
 * @author admin
 */
public class Truyen extends ThuocTinh {

    private String theLoaiTruyen;

    public Truyen(String theLoaiTruyen, int soThuTu, String maSach, int namXuatBan, int soTrang, int soLuong, String tenSach, String tacGia, String nhaXuatBan, String ngonNgu, boolean loaiSach, ngay ngayNhap, double giaTien, int soLuongTrongKho) {
        super(soThuTu, maSach, namXuatBan, soTrang, soLuong, tenSach, tacGia, nhaXuatBan, ngonNgu, loaiSach, ngayNhap, giaTien, soLuongTrongKho);
        this.theLoaiTruyen = theLoaiTruyen;
    }

   

    public String getTheLoaiTruyen() {
        return theLoaiTruyen;
    }

    public void setTheLoaiTruyen(String theLoaiTruyen) {
        this.theLoaiTruyen = theLoaiTruyen;
    }

   

    @Override
    public String toString() {
        return "Truyện" + super.toString() + ", thể loại: " + theLoaiTruyen + ", tình trạng: " + gettinhTrang() + ", tổng tiền đã nhập: " + getTienDaNhap();
    }

    @Override
    public String gettinhTrang() {
        if (getSoLuongTrongKho()== 0) {
            return "Đã hết";
        }
        return "Sẵn sàng cho thuê";
    }

    @Override
    public double getTienDaNhap() {
        return getSoLuong() * getGiaTien();

    }

}
