/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DoAn_CSS311_ThanhTai;

/**
 *
 * @author admin
 */
public abstract class ThuocTinh {

    private int namXuatBan, soTrang, soLuong;
    private String tenSach, tacGia, nhaXuatBan, ngonNgu, maSach;
    private boolean loaiSach;
    public ngay ngayNhap;
    public double giaTien;
    private int soLuongTrongKho;
    private int soThuTu;

    public ThuocTinh() {
    }

    public ThuocTinh(int soThuTu, String maSach, int namXuatBan, int soTrang, int soLuong, String tenSach, String tacGia, String nhaXuatBan, String ngonNgu, boolean loaiSach, ngay ngayNhap, double giaTien, int soLuongTrongKho) {
        this.soThuTu = soThuTu;
        this.maSach = maSach;
        this.namXuatBan = namXuatBan;
        this.soTrang = soTrang;
        this.soLuong = soLuong;
        this.tenSach = tenSach;
        this.tacGia = tacGia;
        this.nhaXuatBan = nhaXuatBan;
        this.ngonNgu = ngonNgu;
        this.loaiSach = loaiSach;
        this.ngayNhap = ngayNhap;
        this.giaTien = giaTien;
        this.soLuongTrongKho = soLuongTrongKho;
    }

    public int getSoThuTu() {
        return soThuTu;
    }

    public void setSoThuTu(int soThuTu) {
        this.soThuTu = soThuTu;
    }
    
    

    public String getMaSach() {
        return maSach;
    }

    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public int getNamXuatBan() {
        return namXuatBan;
    }

    public void setNamXuatBan(int namXuatBan) {
        this.namXuatBan = namXuatBan;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public String getTacGia() {
        return tacGia;
    }

    public void setTacGia(String tacGia) {
        this.tacGia = tacGia;
    }

    public String getNhaXuatBan() {
        return nhaXuatBan;
    }

    public void setNhaXuatBan(String nhaXuatBan) {
        this.nhaXuatBan = nhaXuatBan;
    }

    public String getNgonNgu() {
        return ngonNgu;
    }

    public void setNgonNgu(String ngonNgu) {
        this.ngonNgu = ngonNgu;
    }

    public boolean isLoaiSach() {
        return loaiSach;
    }

    public void setLoaiSach(boolean loaiSach) {
        this.loaiSach = loaiSach;
    }

    public ngay getNgayNhap() {
        return ngayNhap;
    }

    public void setNgayNhap(ngay ngayNhap) {
        this.ngayNhap = ngayNhap;
    }

    public double getGiaTien() {
        return giaTien;
    }

    public void setGiaTien(double giaTien) {
        this.giaTien = giaTien;
    }

    public int getSoLuongTrongKho() {
        return soLuongTrongKho;
    }

    public void setSoLuongTrongKho(int soLuongTrongKho) {
        this.soLuongTrongKho = soLuongTrongKho;
    }

  
    @Override
    public String toString() {
        String loaiSachla = isLoaiSach() ? "Sách Giáo Khoa" : "Truyện";
        return ", số thứ tự: " +soThuTu +", mã sách: " + maSach + ", tên sách: " + tenSach + 
                ", năm xuất bản: " + namXuatBan + ", số trang: " + soTrang + ", số lượng nhập: " + 
                soLuong + ", số lượng trong kho: " + soLuongTrongKho + ", tác giả: " + tacGia + ", nhà xuất bản: " + nhaXuatBan + 
                ", ngôn ngữ: " + ngonNgu + ", loại sách: " + loaiSachla + ", ngày nhập: " + ngayNhap + ", giá tiền: " + giaTien;
    }

    public abstract String gettinhTrang();

    public abstract double getTienDaNhap();

}
